# Week 7: Scaling Political Texts

[Student slides: HTML](W7/slide/week7.html) · [Student slides: PDF](W7/slide/week7.pdf)

We use this package to edit and render the student slides. It includes the QMD,
slide images, styles, the current HTML and PDF, and the classroom R script and
speech data. We keep the supplied folder structure so that the images, styles
and data remain available.

## Classroom exercise

[R script](W7/classroom/W7_scaling.R) · [Instructions](W7/classroom/README.md) ·
[Lab ZIP](W7/downloads/week7-classroom.zip)

With `quanteda` and `quanteda.textmodels` installed, we open `W7_scaling.R` and
run S01–S08b, including the lettered substeps, in one R session. We follow the
Instructions page as we compare the two models and read the speeches.

## Edit and render

We edit `W7/slide/week7.qmd`. With Quarto, R, and the R packages `knitr` and
`rmarkdown` installed, we run this command from the extracted
`week7-student-source` folder:

```sh
quarto render W7/slide/week7.qmd
```

The build displays the R examples and recorded outputs without fitting the models
again. It produces the HTML; the supplied PDF is exported separately.

We keep `styles/`, `image/`, and `W7/assets/` in their supplied locations. Links to
Benoit's lecture open the author's public PDF at the cited page.

The package includes the student slide source, assets and classroom exercise.
Presenter notes remain outside the student package.
