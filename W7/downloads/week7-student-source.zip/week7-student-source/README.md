# Week 7: Scaling Political Texts

[Student slides: HTML](W7/slide/week7.html) · [Student slides: PDF](W7/slide/week7.pdf)

We use this package to edit and render the student slides. It includes the QMD,
slide images, styles, the current HTML and PDF, and the lab handout, R script
and speech data. We keep the supplied folder structure so that the images,
styles and data remain available.

## Lab

[Lab HTML](W7/lab/Lab_Session_W7.html) · [R script](W7/lab/Lab_Session_W7.R) ·
[Instructions](W7/lab/README.md) · [Lab ZIP](W7/downloads/week7-lab.zip)

With `quanteda` and `quanteda.textmodels` installed, we open `Lab_Session_W7.R`
and run S01–S08b, including the lettered substeps, in one R session. We read
the Lab HTML alongside it: each step includes its executed output and a
discussion question. We can read the supplied HTML offline. The editable
lab source is `W7/lab/source/Lab_Session_W7.qmd`; rendering it reruns the models.

The R practice slides link to the same Lab HTML and Lab ZIP included here.

## Edit and render

We edit `W7/slide/week7.qmd`. With Quarto, R, and the R packages `knitr` and
`rmarkdown` installed, we run this command from the extracted
`week7-student-source` folder:

```sh
quarto render W7/slide/week7.qmd
```

The build displays the R examples and recorded outputs without fitting the models
again. It produces the HTML; the supplied PDF is exported separately.

We keep `styles/`, `image/`, and `W7/assets/` in their supplied locations. Links to
Benoit's lecture open the author's public PDF at the cited page.

The package includes the student slide source, assets and lab exercise.
Presenter notes remain outside the student package.
