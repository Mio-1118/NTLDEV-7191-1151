# Week 7: Scaling Political Texts

[Student slides: HTML](W7/slide/week7.html) · [Student slides: PDF](W7/slide/week7.pdf)

We use this package to edit and render the student slides. It includes the QMD,
slide images, styles, and the current HTML and PDF. We keep the supplied folder
structure so that the images and styles remain available.

## Edit and render

We edit `W7/slide/week7.qmd`. With Quarto, R, and the R packages `knitr` and
`rmarkdown` installed, we run this command from the extracted
`week7-student-source` folder:

```sh
quarto render W7/slide/week7.qmd
```

The build displays the R examples and recorded outputs without fitting the models
again. It produces the HTML; the supplied PDF is exported separately.

We keep `styles/`, `image/`, and `W7/assets/` in their supplied locations. Links to
Benoit's lecture open the author's public PDF at the cited page.

This package contains the student slide source and assets. Lab materials,
standalone classroom R downloads, and presenter notes are held back from this
release.
