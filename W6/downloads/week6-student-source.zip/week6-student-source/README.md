# Week 6: Human Coding and Document Classification

[Slides: HTML](W6/slide/week6.html) · [Slides: PDF](W6/slide/week6.pdf)

The source package contains the editable student QMD, slide images and styles,
rendered slides, and classroom R code and data. Keep the folder structure intact.

## Classroom practice

**Work in pairs (two students).**

Open R in `W6/classroom/`. Install the required packages once:

```r
install.packages(c("quanteda", "quanteda.textmodels", "mlr3", "mlr3learners",
                   "e1071", "stringi"), repos = "https://cloud.r-project.org")
```

Load the packages and check the SVM learner before the exercise:

```r
library(quanteda); library(quanteda.textmodels)
library(mlr3); library(mlr3learners)
library(e1071); library(stringi)
lrn("classif.svm")$id
```

The last line should return `"classif.svm"`. Run `W6_classification.R` one checkpoint
at a time in one R session, following C01–C08 and G01–G03, including their substeps.
Run `error_reading.R` after G03 in the same session. The `Data/` folder contains the
Wang, Day & Wu (2022) and Park (2021) data; `Data/README.md` explains the labels.

The standalone classroom ZIP is also included in `W6/downloads/`.

## Edit and compile the slides

Edit `W6/slide/week6.qmd`. With Quarto, R, and the R packages `knitr` and `rmarkdown`
installed, run this command from the extracted `week6-student-source` folder:

```sh
quarto render W6/slide/week6.qmd
```

Keep `styles/`, `image/`, and `W6/assets/` in their supplied locations. The slide
build displays the R examples without executing them. This command builds the
HTML; the supplied PDF is typeset separately.
